"""
Model Evaluation Module
Calculates performance metrics for regression models
"""

import numpy as np
import pandas as pd
from sklearn.metrics import (
    mean_absolute_error,
    mean_squared_error,
    r2_score,
    mean_absolute_percentage_error,
)


class ModelEvaluator:
    """Evaluate model performance using multiple metrics."""

    @staticmethod
    def calculate_mae(y_true, y_pred):
        """
        Calculate Mean Absolute Error.

        Args:
            y_true (array): True values
            y_pred (array): Predicted values

        Returns:
            float: MAE value
        """
        return mean_absolute_error(y_true, y_pred)

    @staticmethod
    def calculate_mse(y_true, y_pred):
        """
        Calculate Mean Squared Error.

        Args:
            y_true (array): True values
            y_pred (array): Predicted values

        Returns:
            float: MSE value
        """
        return mean_squared_error(y_true, y_pred)

    @staticmethod
    def calculate_rmse(y_true, y_pred):
        """
        Calculate Root Mean Squared Error.

        Args:
            y_true (array): True values
            y_pred (array): Predicted values

        Returns:
            float: RMSE value
        """
        return np.sqrt(mean_squared_error(y_true, y_pred))

    @staticmethod
    def calculate_mape(y_true, y_pred):
        """
        Calculate Mean Absolute Percentage Error.

        Args:
            y_true (array): True values
            y_pred (array): Predicted values

        Returns:
            float: MAPE value
        """
        return mean_absolute_percentage_error(y_true, y_pred)

    @staticmethod
    def calculate_r2(y_true, y_pred):
        """
        Calculate R-squared (Coefficient of Determination).

        Args:
            y_true (array): True values
            y_pred (array): Predicted values

        Returns:
            float: R2 value
        """
        return r2_score(y_true, y_pred)

    @staticmethod
    def calculate_adjusted_r2(y_true, y_pred, n_features):
        """
        Calculate Adjusted R-squared.

        Args:
            y_true (array): True values
            y_pred (array): Predicted values
            n_features (int): Number of features used

        Returns:
            float: Adjusted R2 value
        """
        r2 = r2_score(y_true, y_pred)
        n = len(y_true)
        adj_r2 = 1 - (1 - r2) * (n - 1) / (n - n_features - 1)
        return adj_r2

    @staticmethod
    def evaluate_model(y_true, y_pred, model_name="Model", n_features=None):
        """
        Comprehensive model evaluation.

        Args:
            y_true (array): True values
            y_pred (array): Predicted values
            model_name (str): Name of the model
            n_features (int): Number of features (for adjusted R2)

        Returns:
            dict: Dictionary containing all metrics
        """
        metrics = {
            "Model": model_name,
            "MAE": ModelEvaluator.calculate_mae(y_true, y_pred),
            "MSE": ModelEvaluator.calculate_mse(y_true, y_pred),
            "RMSE": ModelEvaluator.calculate_rmse(y_true, y_pred),
            "MAPE": ModelEvaluator.calculate_mape(y_true, y_pred),
            "R2": ModelEvaluator.calculate_r2(y_true, y_pred),
        }

        if n_features is not None:
            metrics["Adjusted_R2"] = ModelEvaluator.calculate_adjusted_r2(
                y_true, y_pred, n_features
            )

        return metrics

    @staticmethod
    def compare_models(results_dict):
        """
        Compare multiple model results.

        Args:
            results_dict (dict): Dictionary with model names and predictions

        Returns:
            pd.DataFrame: Dataframe with comparison results
        """
        results = []
        for model_name, (y_true, y_pred) in results_dict.items():
            metrics = ModelEvaluator.evaluate_model(
                y_true, y_pred, model_name=model_name
            )
            results.append(metrics)

        return pd.DataFrame(results)

    @staticmethod
    def get_residuals(y_true, y_pred):
        """
        Calculate residuals (errors).

        Args:
            y_true (array): True values
            y_pred (array): Predicted values

        Returns:
            array: Residuals
        """
        return y_true - y_pred

    @staticmethod
    def get_percentage_error(y_true, y_pred):
        """
        Calculate percentage errors.

        Args:
            y_true (array): True values
            y_pred (array): Predicted values

        Returns:
            array: Percentage errors
        """
        return ((y_true - y_pred) / y_true * 100).abs()
