"""
Data Generation Module
Generates synthetic but realistic historical sales data
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from .config import (
    DATASET_SIZE,
    START_DATE,
    BASE_SALES,
    TREND_FACTOR,
    SEASONALITY_FACTOR,
    NOISE_FACTOR,
    RANDOM_STATE,
)


class DataGenerator:
    """Generate realistic historical sales data for training."""

    def __init__(self, size=DATASET_SIZE, random_state=RANDOM_STATE):
        """
        Initialize the data generator.

        Args:
            size (int): Number of data points to generate
            random_state (int): Random seed for reproducibility
        """
        self.size = size
        self.random_state = random_state
        np.random.seed(random_state)

    def generate_sales_data(self):
        """
        Generate synthetic sales data with realistic patterns.

        Returns:
            pd.DataFrame: Generated sales data with date and sales columns
        """
        # Create date range
        start_date = datetime.strptime(START_DATE, "%Y-%m-%d")
        dates = [start_date + timedelta(days=i) for i in range(self.size)]

        # Generate trend component
        trend = np.linspace(0, TREND_FACTOR * BASE_SALES, self.size)

        # Generate seasonality component (yearly pattern)
        seasonality = SEASONALITY_FACTOR * np.sin(
            np.array(range(self.size)) * 2 * np.pi / 365
        )

        # Generate noise
        noise = np.random.normal(0, NOISE_FACTOR, self.size)

        # Combine components
        sales = BASE_SALES + trend + seasonality + noise

        # Ensure sales are positive
        sales = np.maximum(sales, 100)

        # Create DataFrame
        df = pd.DataFrame({"date": dates, "sales": sales})
        df["date"] = pd.to_datetime(df["date"])
        df = df.sort_values("date").reset_index(drop=True)

        return df

    def add_features(self, df):
        """
        Add additional features to the dataset.

        Args:
            df (pd.DataFrame): Input dataframe with date and sales

        Returns:
            pd.DataFrame: Dataframe with additional features
        """
        df = df.copy()
        df["date"] = pd.to_datetime(df["date"])

        # Temporal features
        df["year"] = df["date"].dt.year
        df["month"] = df["date"].dt.month
        df["day"] = df["date"].dt.day
        df["dayofweek"] = df["date"].dt.dayofweek
        df["quarter"] = df["date"].dt.quarter
        df["dayofyear"] = df["date"].dt.dayofyear

        # Is weekend
        df["is_weekend"] = df["dayofweek"].isin([5, 6]).astype(int)

        # Is month end
        df["is_month_end"] = df["date"].dt.is_month_end.astype(int)

        # Is quarter end
        df["is_quarter_end"] = df["date"].dt.is_quarter_end.astype(int)

        return df

    def create_lagged_features(self, df, lags=[7, 14, 30]):
        """
        Create lagged features for time series.

        Args:
            df (pd.DataFrame): Input dataframe
            lags (list): List of lag values

        Returns:
            pd.DataFrame: Dataframe with lagged features
        """
        df = df.copy()

        for lag in lags:
            df[f"sales_lag_{lag}"] = df["sales"].shift(lag)

        # Calculate rolling statistics
        for window in [7, 14, 30]:
            df[f"sales_rolling_mean_{window}"] = df["sales"].rolling(
                window=window
            ).mean()
            df[f"sales_rolling_std_{window}"] = df["sales"].rolling(
                window=window
            ).std()

        return df
