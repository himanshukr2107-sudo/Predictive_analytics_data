"""
Visualization Module
Creates professional plots and visualizations for analysis and reporting
"""

import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import numpy as np
from datetime import datetime

# Set style
sns.set_style("whitegrid")
plt.rcParams["figure.figsize"] = (14, 6)
plt.rcParams["font.size"] = 10


class Visualizer:
    """Create visualizations for sales data and model predictions."""

    @staticmethod
    def plot_sales_trend(df, title="Sales Trend Over Time", figsize=(14, 6)):
        """
        Plot sales trend over time.

        Args:
            df (pd.DataFrame): Dataframe with date and sales columns
            title (str): Plot title
            figsize (tuple): Figure size

        Returns:
            matplotlib.figure.Figure: Figure object
        """
        fig, ax = plt.subplots(figsize=figsize)
        df_sorted = df.sort_values("date")
        ax.plot(df_sorted["date"], df_sorted["sales"], linewidth=2, color="steelblue")
        ax.set_xlabel("Date", fontsize=12)
        ax.set_ylabel("Sales", fontsize=12)
        ax.set_title(title, fontsize=14, fontweight="bold")
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        return fig

    @staticmethod
    def plot_sales_distribution(df, title="Sales Distribution", figsize=(10, 6)):
        """
        Plot distribution of sales.

        Args:
            df (pd.DataFrame): Dataframe with sales column
            title (str): Plot title
            figsize (tuple): Figure size

        Returns:
            matplotlib.figure.Figure: Figure object
        """
        fig, ax = plt.subplots(figsize=figsize)
        ax.hist(df["sales"], bins=50, color="steelblue", alpha=0.7, edgecolor="black")
        ax.set_xlabel("Sales", fontsize=12)
        ax.set_ylabel("Frequency", fontsize=12)
        ax.set_title(title, fontsize=14, fontweight="bold")
        ax.grid(True, alpha=0.3, axis="y")
        plt.tight_layout()
        return fig

    @staticmethod
    def plot_monthly_average(df, title="Average Sales by Month", figsize=(12, 6)):
        """
        Plot average sales by month.

        Args:
            df (pd.DataFrame): Dataframe with date and sales columns
            title (str): Plot title
            figsize (tuple): Figure size

        Returns:
            matplotlib.figure.Figure: Figure object
        """
        df_copy = df.copy()
        df_copy["date"] = pd.to_datetime(df_copy["date"])
        df_copy["year_month"] = df_copy["date"].dt.to_period("M")
        monthly_avg = df_copy.groupby("year_month")["sales"].mean()

        fig, ax = plt.subplots(figsize=figsize)
        ax.bar(range(len(monthly_avg)), monthly_avg.values, color="steelblue", alpha=0.7)
        ax.set_xlabel("Month", fontsize=12)
        ax.set_ylabel("Average Sales", fontsize=12)
        ax.set_title(title, fontsize=14, fontweight="bold")
        ax.set_xticks(range(0, len(monthly_avg), 3))
        ax.set_xticklabels([str(monthly_avg.index[i]) for i in range(0, len(monthly_avg), 3)], rotation=45)
        ax.grid(True, alpha=0.3, axis="y")
        plt.tight_layout()
        return fig

    @staticmethod
    def plot_forecast_comparison(actual_df, forecast_df, title="Forecast vs Actual", figsize=(14, 6)):
        """
        Plot forecast against actual values.

        Args:
            actual_df (pd.DataFrame): Actual sales data
            forecast_df (pd.DataFrame): Forecasted sales data
            title (str): Plot title
            figsize (tuple): Figure size

        Returns:
            matplotlib.figure.Figure: Figure object
        """
        fig, ax = plt.subplots(figsize=figsize)

        actual_sorted = actual_df.sort_values("date")
        ax.plot(
            actual_sorted["date"],
            actual_sorted["sales"],
            label="Actual Sales",
            linewidth=2,
            color="steelblue",
            marker="o",
            markersize=4,
        )

        ax.plot(
            forecast_df["date"],
            forecast_df["forecasted_sales"],
            label="Forecasted Sales",
            linewidth=2,
            color="darkorange",
            marker="s",
            markersize=4,
            linestyle="--",
        )

        ax.set_xlabel("Date", fontsize=12)
        ax.set_ylabel("Sales", fontsize=12)
        ax.set_title(title, fontsize=14, fontweight="bold")
        ax.legend(fontsize=11)
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        return fig

    @staticmethod
    def plot_residuals(y_true, y_pred, title="Model Residuals", figsize=(12, 5)):
        """
        Plot residuals from predictions.

        Args:
            y_true (array): True values
            y_pred (array): Predicted values
            title (str): Plot title
            figsize (tuple): Figure size

        Returns:
            matplotlib.figure.Figure: Figure object
        """
        residuals = y_true - y_pred

        fig, axes = plt.subplots(1, 2, figsize=figsize)

        # Residuals plot
        axes[0].scatter(y_pred, residuals, alpha=0.6, color="steelblue")
        axes[0].axhline(y=0, color="red", linestyle="--", linewidth=2)
        axes[0].set_xlabel("Predicted Values", fontsize=11)
        axes[0].set_ylabel("Residuals", fontsize=11)
        axes[0].set_title("Residuals vs Predicted", fontsize=12, fontweight="bold")
        axes[0].grid(True, alpha=0.3)

        # Residuals distribution
        axes[1].hist(residuals, bins=30, color="steelblue", alpha=0.7, edgecolor="black")
        axes[1].set_xlabel("Residuals", fontsize=11)
        axes[1].set_ylabel("Frequency", fontsize=11)
        axes[1].set_title("Residuals Distribution", fontsize=12, fontweight="bold")
        axes[1].grid(True, alpha=0.3, axis="y")

        plt.suptitle(title, fontsize=14, fontweight="bold", y=1.00)
        plt.tight_layout()
        return fig

    @staticmethod
    def plot_model_comparison(metrics_df, figsize=(12, 6)):
        """
        Plot model comparison metrics.

        Args:
            metrics_df (pd.DataFrame): Dataframe with model metrics
            figsize (tuple): Figure size

        Returns:
            matplotlib.figure.Figure: Figure object
        """
        metrics_cols = [col for col in metrics_df.columns if col != "Model"]
        models = metrics_df["Model"].values

        fig, ax = plt.subplots(figsize=figsize)

        x = np.arange(len(models))
        width = 0.2

        for idx, metric in enumerate(["RMSE", "MAE", "R2"]):
            if metric in metrics_cols:
                values = metrics_df[metric].values
                ax.bar(x + idx * width, values, width, label=metric, alpha=0.8)

        ax.set_xlabel("Models", fontsize=12)
        ax.set_ylabel("Metric Value", fontsize=12)
        ax.set_title("Model Performance Comparison", fontsize=14, fontweight="bold")
        ax.set_xticks(x + width)
        ax.set_xticklabels(models)
        ax.legend()
        ax.grid(True, alpha=0.3, axis="y")
        plt.tight_layout()
        return fig

    @staticmethod
    def plot_actual_vs_predicted(y_true, y_pred, title="Actual vs Predicted", figsize=(8, 8)):
        """
        Plot actual vs predicted scatter plot.

        Args:
            y_true (array): True values
            y_pred (array): Predicted values
            title (str): Plot title
            figsize (tuple): Figure size

        Returns:
            matplotlib.figure.Figure: Figure object
        """
        fig, ax = plt.subplots(figsize=figsize)

        ax.scatter(y_true, y_pred, alpha=0.6, color="steelblue", s=50)

        # Add diagonal line for perfect prediction
        min_val = min(y_true.min(), y_pred.min())
        max_val = max(y_true.max(), y_pred.max())
        ax.plot([min_val, max_val], [min_val, max_val], "r--", linewidth=2, label="Perfect Prediction")

        ax.set_xlabel("Actual Sales", fontsize=12)
        ax.set_ylabel("Predicted Sales", fontsize=12)
        ax.set_title(title, fontsize=14, fontweight="bold")
        ax.legend()
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        return fig

    @staticmethod
    def plot_multiple_forecasts(actual_df, forecasts_dict, title="Multi-Model Forecasts", figsize=(14, 7)):
        """
        Plot forecasts from multiple models.

        Args:
            actual_df (pd.DataFrame): Actual sales data
            forecasts_dict (dict): Dictionary with model names and forecasts
            title (str): Plot title
            figsize (tuple): Figure size

        Returns:
            matplotlib.figure.Figure: Figure object
        """
        fig, ax = plt.subplots(figsize=figsize)

        actual_sorted = actual_df.sort_values("date")
        ax.plot(
            actual_sorted["date"],
            actual_sorted["sales"],
            label="Actual Sales",
            linewidth=2.5,
            color="black",
            marker="o",
            markersize=5,
        )

        colors = ["steelblue", "darkorange", "green", "red", "purple"]
        for idx, (model_name, forecast_df) in enumerate(forecasts_dict.items()):
            ax.plot(
                forecast_df["date"],
                forecast_df["forecasted_sales"],
                label=f"Forecast ({model_name})",
                linewidth=2,
                color=colors[idx % len(colors)],
                marker="s",
                markersize=4,
                linestyle="--",
            )

        ax.set_xlabel("Date", fontsize=12)
        ax.set_ylabel("Sales", fontsize=12)
        ax.set_title(title, fontsize=14, fontweight="bold")
        ax.legend(fontsize=10, loc="best")
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        return fig

    @staticmethod
    def plot_feature_importance(feature_importance_df, title="Feature Importance", figsize=(12, 6)):
        """
        Plot feature importance for tree-based models.

        Args:
            feature_importance_df (pd.DataFrame): Dataframe with feature importance
            title (str): Plot title
            figsize (tuple): Figure size

        Returns:
            matplotlib.figure.Figure: Figure object
        """
        fig, ax = plt.subplots(figsize=figsize)

        top_n = min(15, len(feature_importance_df))
        top_features = feature_importance_df.head(top_n)

        ax.barh(range(len(top_features)), top_features["Importance"].values, color="steelblue")
        ax.set_yticks(range(len(top_features)))
        ax.set_yticklabels(top_features["Feature_Index"].values)
        ax.set_xlabel("Importance", fontsize=12)
        ax.set_title(title, fontsize=14, fontweight="bold")
        ax.grid(True, alpha=0.3, axis="x")
        plt.tight_layout()
        return fig

    @staticmethod
    def save_figure(fig, filename, dpi=300, bbox_inches="tight"):
        """
        Save figure to file.

        Args:
            fig (matplotlib.figure.Figure): Figure object
            filename (str): Output filename
            dpi (int): Resolution
            bbox_inches (str): Bounding box setting
        """
        fig.savefig(filename, dpi=dpi, bbox_inches=bbox_inches)
        print(f"Figure saved to {filename}")
