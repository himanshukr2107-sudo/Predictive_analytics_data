"""
Configuration Management for Sales Forecasting Project
Handles all constants and configuration parameters
"""

import os
from pathlib import Path

# Project Paths
PROJECT_ROOT = Path(__file__).parent.parent
DATA_DIR = PROJECT_ROOT / "data"
MODELS_DIR = PROJECT_ROOT / "models"
OUTPUT_DIR = PROJECT_ROOT / "output"

# Ensure directories exist
DATA_DIR.mkdir(exist_ok=True)
MODELS_DIR.mkdir(exist_ok=True)
OUTPUT_DIR.mkdir(exist_ok=True)

# Data Paths
RAW_DATA_PATH = DATA_DIR / "raw_sales_data.csv"
PROCESSED_DATA_PATH = DATA_DIR / "processed_sales_data.csv"

# Model Paths
LINEAR_MODEL_PATH = MODELS_DIR / "linear_regression_model.pkl"
DECISION_TREE_MODEL_PATH = MODELS_DIR / "decision_tree_model.pkl"
RANDOM_FOREST_MODEL_PATH = MODELS_DIR / "random_forest_model.pkl"

# Scaler Path
SCALER_PATH = MODELS_DIR / "scaler.pkl"

# Data Generation Parameters
DATASET_SIZE = 1095  # 3 years of daily data
START_DATE = "2021-01-01"
BASE_SALES = 1000
TREND_FACTOR = 1.5
SEASONALITY_FACTOR = 150
NOISE_FACTOR = 100

# Feature Engineering Parameters
LOOKBACK_PERIOD = 30
FORECAST_PERIOD = 30

# Model Training Parameters
TEST_SIZE = 0.2
RANDOM_STATE = 42
N_ESTIMATORS = 100
MAX_DEPTH = 15

# Evaluation Metrics
METRICS = ["MAE", "MSE", "RMSE", "R2"]

# Display Settings
DECIMAL_PLACES = 4
DATE_FORMAT = "%Y-%m-%d"

# Streamlit Configuration
STREAMLIT_THEME = "light"
MAX_UPLOAD_SIZE = 100  # MB
