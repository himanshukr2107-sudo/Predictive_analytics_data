"""
Data Preprocessing Module
Handles data cleaning, validation, and preparation
"""

import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
import joblib
from .config import SCALER_PATH, PROCESSED_DATA_PATH


class DataPreprocessor:
    """Handle data cleaning and preprocessing."""

    def __init__(self):
        """Initialize the preprocessor."""
        self.scaler = StandardScaler()
        self.feature_columns = None
        self.numeric_columns = None

    def validate_data(self, df):
        """
        Validate input data.

        Args:
            df (pd.DataFrame): Input dataframe

        Returns:
            tuple: (is_valid, error_message)
        """
        if df is None or df.empty:
            return False, "Dataset is empty"

        if "date" not in df.columns or "sales" not in df.columns:
            return False, "Dataset must contain 'date' and 'sales' columns"

        if len(df) < 100:
            return False, "Dataset must have at least 100 rows"

        return True, "Dataset is valid"

    def handle_missing_values(self, df, method="forward_fill"):
        """
        Handle missing values in the dataset.

        Args:
            df (pd.DataFrame): Input dataframe
            method (str): Method to fill missing values

        Returns:
            pd.DataFrame: Dataframe with missing values handled
        """
        df = df.copy()

        if method == "forward_fill":
            df = df.ffill()
            df = df.bfill()
        elif method == "mean":
            numeric_cols = df.select_dtypes(include=[np.number]).columns
            df[numeric_cols] = df[numeric_cols].fillna(df[numeric_cols].mean())
        elif method == "drop":
            df = df.dropna()

        return df

    def remove_outliers(self, df, column="sales", method="iqr", threshold=1.5):
        """
        Remove outliers using IQR method.

        Args:
            df (pd.DataFrame): Input dataframe
            column (str): Column to check for outliers
            method (str): Outlier detection method
            threshold (float): IQR threshold

        Returns:
            pd.DataFrame: Dataframe with outliers removed
        """
        df = df.copy()

        if method == "iqr":
            Q1 = df[column].quantile(0.25)
            Q3 = df[column].quantile(0.75)
            IQR = Q3 - Q1

            lower_bound = Q1 - threshold * IQR
            upper_bound = Q3 + threshold * IQR

            df = df[(df[column] >= lower_bound) & (df[column] <= upper_bound)]

        elif method == "zscore":
            z_scores = np.abs((df[column] - df[column].mean()) / df[column].std())
            df = df[z_scores < threshold]

        return df.reset_index(drop=True)

    def normalize_features(self, df, columns=None, fit=False):
        """
        Normalize numerical features using StandardScaler.

        Args:
            df (pd.DataFrame): Input dataframe
            columns (list): Columns to normalize
            fit (bool): Whether to fit the scaler

        Returns:
            pd.DataFrame: Dataframe with normalized features
        """
        df = df.copy()

        if columns is None:
            columns = df.select_dtypes(include=[np.number]).columns.tolist()
            if "sales" in columns:
                columns.remove("sales")

        if fit:
            self.scaler.fit(df[columns])
            joblib.dump(self.scaler, SCALER_PATH)
        else:
            try:
                self.scaler = joblib.load(SCALER_PATH)
            except FileNotFoundError:
                print("Scaler not found. Fitting new scaler.")
                self.scaler.fit(df[columns])

        df[columns] = self.scaler.transform(df[columns])
        self.feature_columns = columns

        return df

    def preprocess(self, df, handle_outliers=True, normalize=True, fit=False):
        """
        Complete preprocessing pipeline.

        Args:
            df (pd.DataFrame): Input dataframe
            handle_outliers (bool): Whether to remove outliers
            normalize (bool): Whether to normalize features
            fit (bool): Whether to fit scalers

        Returns:
            pd.DataFrame: Preprocessed dataframe
        """
        # Validate data
        is_valid, message = self.validate_data(df)
        if not is_valid:
            raise ValueError(f"Data validation failed: {message}")

        # Handle missing values
        df = self.handle_missing_values(df)

        # Remove outliers
        if handle_outliers:
            df = self.remove_outliers(df)

        # Normalize features
        if normalize:
            df = self.normalize_features(df, fit=fit)

        return df

    def save_preprocessed_data(self, df, path=PROCESSED_DATA_PATH):
        """
        Save preprocessed data to CSV.

        Args:
            df (pd.DataFrame): Dataframe to save
            path (str): Path to save the file
        """
        df.to_csv(path, index=False)
        print(f"Preprocessed data saved to {path}")

    def load_preprocessed_data(self, path=PROCESSED_DATA_PATH):
        """
        Load preprocessed data from CSV.

        Args:
            path (str): Path to load the file

        Returns:
            pd.DataFrame: Loaded dataframe
        """
        df = pd.read_csv(path)
        df["date"] = pd.to_datetime(df["date"])
        return df
