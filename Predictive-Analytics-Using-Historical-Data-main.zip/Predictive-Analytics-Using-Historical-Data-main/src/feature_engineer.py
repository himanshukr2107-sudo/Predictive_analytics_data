"""
Feature Engineering Module
Creates advanced features for better model performance
"""

import pandas as pd
import numpy as np
from .config import LOOKBACK_PERIOD


class FeatureEngineer:
    """Handle feature engineering and creation."""

    def __init__(self, lookback_period=LOOKBACK_PERIOD):
        """
        Initialize the feature engineer.

        Args:
            lookback_period (int): Number of days to look back for lagged features
        """
        self.lookback_period = lookback_period

    def create_temporal_features(self, df):
        """
        Create temporal features from date column.

        Args:
            df (pd.DataFrame): Input dataframe with date column

        Returns:
            pd.DataFrame: Dataframe with temporal features
        """
        df = df.copy()
        df["date"] = pd.to_datetime(df["date"])

        # Calendar features
        df["year"] = df["date"].dt.year
        df["month"] = df["date"].dt.month
        df["day"] = df["date"].dt.day
        df["dayofweek"] = df["date"].dt.dayofweek
        df["quarter"] = df["date"].dt.quarter
        df["dayofyear"] = df["date"].dt.dayofyear
        df["week"] = df["date"].dt.isocalendar().week

        # Binary features
        df["is_weekend"] = df["dayofweek"].isin([5, 6]).astype(int)
        df["is_month_start"] = df["date"].dt.is_month_start.astype(int)
        df["is_month_end"] = df["date"].dt.is_month_end.astype(int)
        df["is_quarter_end"] = df["date"].dt.is_quarter_end.astype(int)

        return df

    def create_lagged_features(self, df, lags=None):
        """
        Create lagged features from sales column.

        Args:
            df (pd.DataFrame): Input dataframe with sales column
            lags (list): List of lag periods

        Returns:
            pd.DataFrame: Dataframe with lagged features
        """
        if lags is None:
            lags = [1, 7, 14, 30]

        df = df.copy()

        for lag in lags:
            df[f"sales_lag_{lag}"] = df["sales"].shift(lag)

        return df

    def create_rolling_features(self, df, windows=None):
        """
        Create rolling statistics features.

        Args:
            df (pd.DataFrame): Input dataframe with sales column
            windows (list): List of rolling window sizes

        Returns:
            pd.DataFrame: Dataframe with rolling features
        """
        if windows is None:
            windows = [7, 14, 30]

        df = df.copy()

        for window in windows:
            df[f"sales_rolling_mean_{window}"] = df["sales"].rolling(
                window=window, min_periods=1
            ).mean()
            df[f"sales_rolling_std_{window}"] = df["sales"].rolling(
                window=window, min_periods=1
            ).std()
            df[f"sales_rolling_min_{window}"] = df["sales"].rolling(
                window=window, min_periods=1
            ).min()
            df[f"sales_rolling_max_{window}"] = df["sales"].rolling(
                window=window, min_periods=1
            ).max()

        return df

    def create_exponential_features(self, df, alpha=0.3):
        """
        Create exponential moving average features.

        Args:
            df (pd.DataFrame): Input dataframe with sales column
            alpha (float): Smoothing factor for EMA

        Returns:
            pd.DataFrame: Dataframe with exponential features
        """
        df = df.copy()

        df["sales_ema_7"] = df["sales"].ewm(span=7, adjust=False).mean()
        df["sales_ema_14"] = df["sales"].ewm(span=14, adjust=False).mean()
        df["sales_ema_30"] = df["sales"].ewm(span=30, adjust=False).mean()

        return df

    def create_trend_features(self, df):
        """
        Create trend-based features.

        Args:
            df (pd.DataFrame): Input dataframe with sales column

        Returns:
            pd.DataFrame: Dataframe with trend features
        """
        df = df.copy()

        # Calculate differences (momentum)
        df["sales_diff_1"] = df["sales"].diff(1)
        df["sales_diff_7"] = df["sales"].diff(7)

        # Calculate percentage change
        df["sales_pct_change_1"] = df["sales"].pct_change(1)
        df["sales_pct_change_7"] = df["sales"].pct_change(7)

        return df

    def create_cyclical_features(self, df):
        """
        Create cyclical encoding of temporal features.

        Args:
            df (pd.DataFrame): Input dataframe with month and dayofweek

        Returns:
            pd.DataFrame: Dataframe with cyclical features
        """
        df = df.copy()

        # Cyclical encoding for month
        df["month_sin"] = np.sin(2 * np.pi * df["month"] / 12)
        df["month_cos"] = np.cos(2 * np.pi * df["month"] / 12)

        # Cyclical encoding for day of week
        df["dayofweek_sin"] = np.sin(2 * np.pi * df["dayofweek"] / 7)
        df["dayofweek_cos"] = np.cos(2 * np.pi * df["dayofweek"] / 7)

        return df

    def engineer_features(self, df):
        """
        Execute complete feature engineering pipeline.

        Args:
            df (pd.DataFrame): Input dataframe

        Returns:
            pd.DataFrame: Dataframe with all engineered features
        """
        df = self.create_temporal_features(df)
        df = self.create_lagged_features(df)
        df = self.create_rolling_features(df)
        df = self.create_exponential_features(df)
        df = self.create_trend_features(df)
        df = self.create_cyclical_features(df)

        return df

    def get_feature_names(self, df):
        """
        Get all feature column names excluding target and date.

        Args:
            df (pd.DataFrame): Input dataframe

        Returns:
            list: List of feature column names
        """
        exclude_cols = ["date", "sales"]
        return [col for col in df.columns if col not in exclude_cols]
