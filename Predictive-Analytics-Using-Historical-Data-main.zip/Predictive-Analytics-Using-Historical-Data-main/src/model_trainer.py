"""
Model Training Module
Trains multiple regression models for sales forecasting
"""

import numpy as np
import pandas as pd
import joblib
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import StandardScaler
from .config import (
    LINEAR_MODEL_PATH,
    DECISION_TREE_MODEL_PATH,
    RANDOM_FOREST_MODEL_PATH,
    TEST_SIZE,
    RANDOM_STATE,
    N_ESTIMATORS,
    MAX_DEPTH,
)


class ModelTrainer:
    """Train and save machine learning models."""

    def __init__(self, test_size=TEST_SIZE, random_state=RANDOM_STATE):
        """
        Initialize the model trainer.

        Args:
            test_size (float): Proportion of data to use for testing
            random_state (int): Random seed for reproducibility
        """
        self.test_size = test_size
        self.random_state = random_state
        self.models = {}
        self.X_train = None
        self.X_test = None
        self.y_train = None
        self.y_test = None

    def prepare_data(self, df, feature_columns):
        """
        Prepare data for training.

        Args:
            df (pd.DataFrame): Input dataframe
            feature_columns (list): List of feature column names

        Returns:
            tuple: X_train, X_test, y_train, y_test
        """
        # Remove rows with NaN values
        df_clean = df.dropna()

        X = df_clean[feature_columns]
        y = df_clean["sales"]

        # Split data
        self.X_train, self.X_test, self.y_train, self.y_test = train_test_split(
            X, y, test_size=self.test_size, random_state=self.random_state
        )

        return self.X_train, self.X_test, self.y_train, self.y_test

    def train_linear_regression(self):
        """
        Train Linear Regression model.

        Returns:
            LinearRegression: Trained model
        """
        model = LinearRegression()
        model.fit(self.X_train, self.y_train)
        self.models["Linear Regression"] = model
        return model

    def train_decision_tree(self, max_depth=MAX_DEPTH):
        """
        Train Decision Tree Regressor model.

        Args:
            max_depth (int): Maximum depth of the tree

        Returns:
            DecisionTreeRegressor: Trained model
        """
        model = DecisionTreeRegressor(
            max_depth=max_depth, random_state=self.random_state
        )
        model.fit(self.X_train, self.y_train)
        self.models["Decision Tree"] = model
        return model

    def train_random_forest(self, n_estimators=N_ESTIMATORS, max_depth=MAX_DEPTH):
        """
        Train Random Forest Regressor model.

        Args:
            n_estimators (int): Number of trees in the forest
            max_depth (int): Maximum depth of the trees

        Returns:
            RandomForestRegressor: Trained model
        """
        model = RandomForestRegressor(
            n_estimators=n_estimators,
            max_depth=max_depth,
            random_state=self.random_state,
            n_jobs=-1,
        )
        model.fit(self.X_train, self.y_train)
        self.models["Random Forest"] = model
        return model

    def train_all_models(self):
        """
        Train all models.

        Returns:
            dict: Dictionary of trained models
        """
        self.train_linear_regression()
        self.train_decision_tree()
        self.train_random_forest()
        return self.models

    def save_model(self, model, model_name, path=None):
        """
        Save a trained model to disk.

        Args:
            model: Trained model to save
            model_name (str): Name of the model
            path (str): Path to save the model
        """
        if path is None:
            if model_name == "Linear Regression":
                path = LINEAR_MODEL_PATH
            elif model_name == "Decision Tree":
                path = DECISION_TREE_MODEL_PATH
            elif model_name == "Random Forest":
                path = RANDOM_FOREST_MODEL_PATH

        joblib.dump(model, path)
        print(f"Model {model_name} saved to {path}")

    def save_all_models(self):
        """Save all trained models."""
        for model_name, model in self.models.items():
            self.save_model(model, model_name)

    def load_model(self, model_name, path=None):
        """
        Load a saved model from disk.

        Args:
            model_name (str): Name of the model
            path (str): Path to load the model from

        Returns:
            Loaded model
        """
        if path is None:
            if model_name == "Linear Regression":
                path = LINEAR_MODEL_PATH
            elif model_name == "Decision Tree":
                path = DECISION_TREE_MODEL_PATH
            elif model_name == "Random Forest":
                path = RANDOM_FOREST_MODEL_PATH

        try:
            model = joblib.load(path)
            self.models[model_name] = model
            return model
        except FileNotFoundError:
            print(f"Model file not found at {path}")
            return None

    def predict(self, model, X):
        """
        Make predictions using a trained model.

        Args:
            model: Trained model
            X (pd.DataFrame): Input features

        Returns:
            array: Predictions
        """
        return model.predict(X)

    def get_feature_importance(self, model_name):
        """
        Get feature importance for tree-based models.

        Args:
            model_name (str): Name of the model

        Returns:
            pd.DataFrame: Feature importance dataframe or None
        """
        if model_name not in self.models:
            return None

        model = self.models[model_name]

        if not hasattr(model, "feature_importances_"):
            return None

        # This would need feature names to be more useful
        importances = model.feature_importances_
        return pd.DataFrame(
            {"Feature_Index": range(len(importances)), "Importance": importances}
        ).sort_values("Importance", ascending=False)

    def get_model_info(self, model_name):
        """
        Get information about a trained model.

        Args:
            model_name (str): Name of the model

        Returns:
            dict: Model information
        """
        if model_name not in self.models:
            return None

        model = self.models[model_name]
        info = {
            "Model_Name": model_name,
            "Model_Type": type(model).__name__,
            "Training_Samples": self.X_train.shape[0] if self.X_train is not None else None,
            "Test_Samples": self.X_test.shape[0] if self.X_test is not None else None,
            "Number_of_Features": self.X_train.shape[1] if self.X_train is not None else None,
        }

        if hasattr(model, "coef_"):
            info["Coefficients_Count"] = len(model.coef_)

        return info
