"""
Forecasting Module
Makes future predictions using trained models
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import joblib
from .config import LINEAR_MODEL_PATH, DECISION_TREE_MODEL_PATH, RANDOM_FOREST_MODEL_PATH


class SalesForecaster:
    """Make future sales predictions using trained models."""

    def __init__(self):
        """Initialize the forecaster."""
        self.models = {}
        self.feature_engineer = None
        self.last_known_date = None
        self.last_known_sales = None

    def load_models(self):
        """Load all trained models from disk."""
        try:
            self.models["Linear Regression"] = joblib.load(LINEAR_MODEL_PATH)
        except FileNotFoundError:
            print(f"Linear Regression model not found at {LINEAR_MODEL_PATH}")

        try:
            self.models["Decision Tree"] = joblib.load(DECISION_TREE_MODEL_PATH)
        except FileNotFoundError:
            print(f"Decision Tree model not found at {DECISION_TREE_MODEL_PATH}")

        try:
            self.models["Random Forest"] = joblib.load(RANDOM_FOREST_MODEL_PATH)
        except FileNotFoundError:
            print(f"Random Forest model not found at {RANDOM_FOREST_MODEL_PATH}")

        return self.models

    def generate_future_dates(self, last_date, periods=30):
        """
        Generate future dates for forecasting.

        Args:
            last_date (datetime): Last date in the training data
            periods (int): Number of days to forecast

        Returns:
            list: List of future dates
        """
        future_dates = [last_date + timedelta(days=i + 1) for i in range(periods)]
        return future_dates

    def create_forecast_features(self, df, future_dates, feature_engineer):
        """
        Create features for future forecast period.

        Args:
            df (pd.DataFrame): Historical data with features
            future_dates (list): List of future dates
            feature_engineer: FeatureEngineer instance

        Returns:
            pd.DataFrame: Dataframe with future dates and engineered features
        """
        # Create base dataframe for future dates
        forecast_df = pd.DataFrame({"date": future_dates})
        forecast_df["date"] = pd.to_datetime(forecast_df["date"])

        # Create temporal features
        forecast_df["year"] = forecast_df["date"].dt.year
        forecast_df["month"] = forecast_df["date"].dt.month
        forecast_df["day"] = forecast_df["date"].dt.day
        forecast_df["dayofweek"] = forecast_df["date"].dt.dayofweek
        forecast_df["quarter"] = forecast_df["date"].dt.quarter
        forecast_df["dayofyear"] = forecast_df["date"].dt.dayofyear
        forecast_df["week"] = forecast_df["date"].dt.isocalendar().week

        # Binary features
        forecast_df["is_weekend"] = forecast_df["dayofweek"].isin([5, 6]).astype(int)
        forecast_df["is_month_start"] = (
            forecast_df["date"].dt.is_month_start.astype(int)
        )
        forecast_df["is_month_end"] = forecast_df["date"].dt.is_month_end.astype(int)
        forecast_df["is_quarter_end"] = (
            forecast_df["date"].dt.is_quarter_end.astype(int)
        )

        # Get last values for lagged and rolling features
        if len(df) > 0:
            last_sales_values = df["sales"].tail(30).values

            # Lagged features - use last known values
            forecast_df["sales_lag_1"] = last_sales_values[-1] if len(
                last_sales_values
            ) > 0 else 0
            forecast_df["sales_lag_7"] = (
                np.mean(last_sales_values[-7:]) if len(last_sales_values) >= 7 else last_sales_values[-1] if len(last_sales_values) > 0 else 0
            )
            forecast_df["sales_lag_14"] = (
                np.mean(last_sales_values[-14:]) if len(last_sales_values) >= 14 else last_sales_values[-1] if len(last_sales_values) > 0 else 0
            )
            forecast_df["sales_lag_30"] = (
                np.mean(last_sales_values[-30:]) if len(last_sales_values) >= 30 else last_sales_values[-1] if len(last_sales_values) > 0 else 0
            )

            # Rolling mean features
            forecast_df["sales_rolling_mean_7"] = np.mean(
                last_sales_values[-7:] if len(last_sales_values) >= 7 else last_sales_values
            )
            forecast_df["sales_rolling_mean_14"] = np.mean(
                last_sales_values[-14:] if len(last_sales_values) >= 14 else last_sales_values
            )
            forecast_df["sales_rolling_mean_30"] = np.mean(
                last_sales_values[-30:] if len(last_sales_values) >= 30 else last_sales_values
            )

            # Rolling std features
            forecast_df["sales_rolling_std_7"] = np.std(
                last_sales_values[-7:] if len(last_sales_values) >= 7 else last_sales_values
            )
            forecast_df["sales_rolling_std_14"] = np.std(
                last_sales_values[-14:] if len(last_sales_values) >= 14 else last_sales_values
            )
            forecast_df["sales_rolling_std_30"] = np.std(
                last_sales_values[-30:] if len(last_sales_values) >= 30 else last_sales_values
            )

            # Min/Max features
            forecast_df["sales_rolling_min_7"] = np.min(
                last_sales_values[-7:] if len(last_sales_values) >= 7 else last_sales_values
            )
            forecast_df["sales_rolling_max_7"] = np.max(
                last_sales_values[-7:] if len(last_sales_values) >= 7 else last_sales_values
            )

            # EMA features
            forecast_df["sales_ema_7"] = last_sales_values[-1] if len(last_sales_values) > 0 else 0
            forecast_df["sales_ema_14"] = (
                np.mean(last_sales_values[-14:]) if len(last_sales_values) >= 14 else last_sales_values[-1] if len(last_sales_values) > 0 else 0
            )
            forecast_df["sales_ema_30"] = (
                np.mean(last_sales_values[-30:]) if len(last_sales_values) >= 30 else last_sales_values[-1] if len(last_sales_values) > 0 else 0
            )

            # Trend features
            forecast_df["sales_diff_1"] = (
                last_sales_values[-1] - last_sales_values[-2]
                if len(last_sales_values) > 1
                else 0
            )
            forecast_df["sales_diff_7"] = (
                last_sales_values[-1] - last_sales_values[-7]
                if len(last_sales_values) > 7
                else 0
            )

            # Percentage change
            forecast_df["sales_pct_change_1"] = (
                (last_sales_values[-1] - last_sales_values[-2])
                / last_sales_values[-2]
                if len(last_sales_values) > 1 and last_sales_values[-2] > 0
                else 0
            )
            forecast_df["sales_pct_change_7"] = (
                (last_sales_values[-1] - last_sales_values[-7])
                / last_sales_values[-7]
                if len(last_sales_values) > 7 and last_sales_values[-7] > 0
                else 0
            )

        # Cyclical features
        forecast_df["month_sin"] = np.sin(2 * np.pi * forecast_df["month"] / 12)
        forecast_df["month_cos"] = np.cos(2 * np.pi * forecast_df["month"] / 12)
        forecast_df["dayofweek_sin"] = np.sin(
            2 * np.pi * forecast_df["dayofweek"] / 7
        )
        forecast_df["dayofweek_cos"] = np.cos(
            2 * np.pi * forecast_df["dayofweek"] / 7
        )

        # Min/Max 14/30 features if not already added
        if "sales_rolling_min_14" not in forecast_df.columns:
            forecast_df["sales_rolling_min_14"] = forecast_df["sales_rolling_min_7"]
            forecast_df["sales_rolling_max_14"] = forecast_df["sales_rolling_max_7"]
            forecast_df["sales_rolling_min_30"] = forecast_df["sales_rolling_min_7"]
            forecast_df["sales_rolling_max_30"] = forecast_df["sales_rolling_max_7"]

        return forecast_df

    def forecast(self, df, periods=30, model_name="Random Forest", feature_engineer=None):
        """
        Generate sales forecast for future periods.

        Args:
            df (pd.DataFrame): Historical data with all features
            periods (int): Number of days to forecast
            model_name (str): Name of model to use for forecasting
            feature_engineer: FeatureEngineer instance

        Returns:
            pd.DataFrame: Forecast results
        """
        if model_name not in self.models:
            self.load_models()

        if model_name not in self.models:
            raise ValueError(f"Model {model_name} not found")

        model = self.models[model_name]

        # Get last date
        last_date = pd.to_datetime(df["date"]).max()
        future_dates = self.generate_future_dates(last_date, periods)

        # Create forecast features
        forecast_features = self.create_forecast_features(df, future_dates, feature_engineer)

        # Get feature columns (exclude date)
        feature_columns = [col for col in forecast_features.columns if col != "date"]

        # Make predictions
        X_forecast = forecast_features[feature_columns]
        predictions = model.predict(X_forecast)

        # Create results dataframe
        results = pd.DataFrame(
            {
                "date": forecast_features["date"],
                "forecasted_sales": predictions,
                "model_used": model_name,
            }
        )

        return results

    def forecast_multiple_models(self, df, periods=30, feature_engineer=None):
        """
        Generate forecasts using all available models.

        Args:
            df (pd.DataFrame): Historical data with all features
            periods (int): Number of days to forecast
            feature_engineer: FeatureEngineer instance

        Returns:
            dict: Dictionary with forecasts from each model
        """
        self.load_models()
        all_forecasts = {}

        for model_name in self.models.keys():
            try:
                forecast = self.forecast(df, periods, model_name, feature_engineer)
                all_forecasts[model_name] = forecast
            except Exception as e:
                print(f"Error forecasting with {model_name}: {str(e)}")

        return all_forecasts

    def ensemble_forecast(self, df, periods=30, feature_engineer=None):
        """
        Generate ensemble forecast (average of all models).

        Args:
            df (pd.DataFrame): Historical data with all features
            periods (int): Number of days to forecast
            feature_engineer: FeatureEngineer instance

        Returns:
            pd.DataFrame: Ensemble forecast results
        """
        all_forecasts = self.forecast_multiple_models(df, periods, feature_engineer)

        if not all_forecasts:
            raise ValueError("No forecasts generated")

        # Get dates from first forecast
        first_forecast = next(iter(all_forecasts.values()))
        dates = first_forecast["date"].values

        # Calculate ensemble average
        predictions = np.mean(
            [forecast["forecasted_sales"].values for forecast in all_forecasts.values()],
            axis=0,
        )

        results = pd.DataFrame(
            {
                "date": dates,
                "forecasted_sales": predictions,
                "model_used": "Ensemble (Average)",
            }
        )

        return results
