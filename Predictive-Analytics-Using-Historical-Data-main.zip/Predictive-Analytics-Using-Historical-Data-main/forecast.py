"""
Forecasting Script
Generate sales forecasts using trained models
"""

import sys
import os
import pandas as pd
import numpy as np
from pathlib import Path

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "src"))

from src import (
    DataPreprocessor,
    FeatureEngineer,
    SalesForecaster,
    Visualizer,
    PROCESSED_DATA_PATH,
)


def main():
    """Main forecasting pipeline."""
    print("=" * 80)
    print("SALES FORECASTING PREDICTION")
    print("=" * 80)

    # Load preprocessed data
    print("\n[STEP 1] Loading preprocessed data...")
    preprocessor = DataPreprocessor()
    df = preprocessor.load_preprocessed_data(PROCESSED_DATA_PATH)
    print(f"✓ Loaded {len(df)} records")

    # Engineer features
    print("\n[STEP 2] Engineering features...")
    feature_engineer = FeatureEngineer()
    df_engineered = feature_engineer.engineer_features(df)
    feature_columns = feature_engineer.get_feature_names(df_engineered)
    print(f"✓ Features engineered ({len(feature_columns)} features)")

    # Initialize forecaster
    print("\n[STEP 3] Loading trained models...")
    forecaster = SalesForecaster()
    models = forecaster.load_models()
    print(f"✓ Loaded {len(models)} models: {list(models.keys())}")

    # Generate forecasts
    print("\n[STEP 4] Generating forecasts for next 30 days...")
    output_dir = Path(__file__).parent / "output"
    output_dir.mkdir(exist_ok=True)

    all_forecasts = forecaster.forecast_multiple_models(df_engineered, periods=30, feature_engineer=feature_engineer)

    # Save forecasts
    print("\n[STEP 5] Saving forecast results...")
    for model_name, forecast_df in all_forecasts.items():
        filename = output_dir / f"forecast_{model_name.replace(' ', '_').lower()}.csv"
        forecast_df.to_csv(filename, index=False)
        print(f"  ✓ {model_name} forecast saved")

    # Generate ensemble forecast
    print("\n[STEP 6] Creating ensemble forecast...")
    ensemble_forecast = forecaster.ensemble_forecast(df_engineered, periods=30, feature_engineer=feature_engineer)
    ensemble_forecast.to_csv(output_dir / "forecast_ensemble.csv", index=False)
    print("✓ Ensemble forecast saved")

    # Create visualizations
    print("\n[STEP 7] Creating visualizations...")
    visualizer = Visualizer()

    # Plot all forecasts
    fig1 = visualizer.plot_multiple_forecasts(df, all_forecasts)
    visualizer.save_figure(fig1, str(output_dir / "07_forecast_all_models.png"))
    print("✓ Multi-model forecast plot saved")

    # Plot ensemble forecast
    fig2 = visualizer.plot_forecast_comparison(df, ensemble_forecast)
    visualizer.save_figure(fig2, str(output_dir / "08_forecast_ensemble.png"))
    print("✓ Ensemble forecast plot saved")

    # Print forecast summary
    print("\n" + "=" * 80)
    print("FORECAST SUMMARY (Next 30 Days)")
    print("=" * 80)

    for model_name, forecast_df in all_forecasts.items():
        avg_forecast = forecast_df["forecasted_sales"].mean()
        min_forecast = forecast_df["forecasted_sales"].min()
        max_forecast = forecast_df["forecasted_sales"].max()
        print(f"\n{model_name}:")
        print(f"  Average: ${avg_forecast:.2f}")
        print(f"  Range: ${min_forecast:.2f} - ${max_forecast:.2f}")

    print(f"\nEnsemble Average: ${ensemble_forecast['forecasted_sales'].mean():.2f}")

    # Save summary
    summary_data = {
        "Model": [],
        "Average_Forecast": [],
        "Min_Forecast": [],
        "Max_Forecast": [],
    }

    for model_name, forecast_df in all_forecasts.items():
        summary_data["Model"].append(model_name)
        summary_data["Average_Forecast"].append(forecast_df["forecasted_sales"].mean())
        summary_data["Min_Forecast"].append(forecast_df["forecasted_sales"].min())
        summary_data["Max_Forecast"].append(forecast_df["forecasted_sales"].max())

    summary_df = pd.DataFrame(summary_data)
    summary_df.to_csv(output_dir / "forecast_summary.csv", index=False)

    print("\n" + "=" * 80)
    print("FORECASTING COMPLETED SUCCESSFULLY")
    print("=" * 80)
    print(f"\nOutput files saved to: {output_dir}")
    print("✓ All forecasts generated!")
    print("=" * 80)


if __name__ == "__main__":
    main()
