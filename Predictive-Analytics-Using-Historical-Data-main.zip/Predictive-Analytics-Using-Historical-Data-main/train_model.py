"""
Main Training Script
Train and save all machine learning models for sales forecasting
"""

import sys
import os
import pandas as pd
import numpy as np
from pathlib import Path

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "src"))

from src import (
    DataGenerator,
    DataPreprocessor,
    FeatureEngineer,
    ModelTrainer,
    ModelEvaluator,
    Visualizer,
    RAW_DATA_PATH,
    PROCESSED_DATA_PATH,
)


def main():
    """Main training pipeline."""
    print("=" * 80)
    print("SALES FORECASTING MODEL TRAINING PIPELINE")
    print("=" * 80)

    # Step 1: Generate Data
    print("\n[STEP 1] Generating synthetic sales data...")
    generator = DataGenerator()
    df = generator.generate_sales_data()
    df = generator.add_features(df)
    df = generator.create_lagged_features(df)
    print(f"✓ Generated {len(df)} data points")
    print(f"  Date range: {df['date'].min().date()} to {df['date'].max().date()}")
    print(f"  Sales range: ${df['sales'].min():.2f} to ${df['sales'].max():.2f}")

    # Save raw data
    df.to_csv(RAW_DATA_PATH, index=False)
    print(f"✓ Raw data saved to {RAW_DATA_PATH}")

    # Step 2: Data Preprocessing
    print("\n[STEP 2] Preprocessing data...")
    preprocessor = DataPreprocessor()
    df_processed = preprocessor.preprocess(df, handle_outliers=True, normalize=True, fit=True)
    print(f"✓ Data preprocessed (shape: {df_processed.shape})")
    print(f"  Missing values: {df_processed.isnull().sum().sum()}")

    # Save processed data
    preprocessor.save_preprocessed_data(df_processed)

    # Step 3: Feature Engineering
    print("\n[STEP 3] Engineering features...")
    feature_engineer = FeatureEngineer()
    df_engineered = feature_engineer.engineer_features(df_processed)
    feature_columns = feature_engineer.get_feature_names(df_engineered)
    print(f"✓ Features engineered (total features: {len(feature_columns)})")
    print(f"  Sample features: {feature_columns[:5]}")

    # Step 4: Model Training
    print("\n[STEP 4] Training models...")
    trainer = ModelTrainer()
    X_train, X_test, y_train, y_test = trainer.prepare_data(df_engineered, feature_columns)
    print(f"✓ Data split - Training: {X_train.shape[0]}, Test: {X_test.shape[0]}")

    # Train models
    print("\n  Training Linear Regression...")
    lr_model = trainer.train_linear_regression()
    print("  ✓ Linear Regression trained")

    print("  Training Decision Tree Regressor...")
    dt_model = trainer.train_decision_tree()
    print("  ✓ Decision Tree trained")

    print("  Training Random Forest Regressor...")
    rf_model = trainer.train_random_forest()
    print("  ✓ Random Forest trained")

    # Step 5: Model Evaluation
    print("\n[STEP 5] Evaluating models...")
    evaluator = ModelEvaluator()

    results = []
    for model_name, model in trainer.models.items():
        y_pred = trainer.predict(model, X_test)
        metrics = evaluator.evaluate_model(
            y_test.values,
            y_pred,
            model_name=model_name,
            n_features=X_test.shape[1],
        )
        results.append(metrics)
        print(f"\n  {model_name}:")
        print(f"    RMSE: {metrics['RMSE']:.4f}")
        print(f"    MAE:  {metrics['MAE']:.4f}")
        print(f"    R²:   {metrics['R2']:.4f}")

    metrics_df = pd.DataFrame(results)

    # Step 6: Save Models
    print("\n[STEP 6] Saving models...")
    trainer.save_all_models()
    print("✓ All models saved successfully")

    # Step 7: Visualizations
    print("\n[STEP 7] Creating visualizations...")
    visualizer = Visualizer()

    # Create output directory if needed
    output_dir = Path(__file__).parent / "output"
    output_dir.mkdir(exist_ok=True)

    # Sales trend
    fig1 = visualizer.plot_sales_trend(df)
    visualizer.save_figure(fig1, str(output_dir / "01_sales_trend.png"))
    print("✓ Sales trend plot saved")

    # Sales distribution
    fig2 = visualizer.plot_sales_distribution(df)
    visualizer.save_figure(fig2, str(output_dir / "02_sales_distribution.png"))
    print("✓ Sales distribution plot saved")

    # Monthly average
    fig3 = visualizer.plot_monthly_average(df)
    visualizer.save_figure(fig3, str(output_dir / "03_monthly_average.png"))
    print("✓ Monthly average plot saved")

    # Model comparison
    fig4 = visualizer.plot_model_comparison(metrics_df)
    visualizer.save_figure(fig4, str(output_dir / "04_model_comparison.png"))
    print("✓ Model comparison plot saved")

    # Residuals for Random Forest
    y_pred_rf = trainer.predict(trainer.models["Random Forest"], X_test)
    fig5 = visualizer.plot_residuals(y_test.values, y_pred_rf, title="Random Forest Residuals")
    visualizer.save_figure(fig5, str(output_dir / "05_residuals.png"))
    print("✓ Residuals plot saved")

    # Actual vs Predicted
    fig6 = visualizer.plot_actual_vs_predicted(y_test.values, y_pred_rf)
    visualizer.save_figure(fig6, str(output_dir / "06_actual_vs_predicted.png"))
    print("✓ Actual vs Predicted plot saved")

    # Save metrics
    metrics_df.to_csv(output_dir / "model_metrics.csv", index=False)
    print("✓ Model metrics saved")

    # Print summary
    print("\n" + "=" * 80)
    print("TRAINING COMPLETED SUCCESSFULLY")
    print("=" * 80)
    print(f"\nSummary:")
    print(f"  - Dataset size: {len(df)} records")
    print(f"  - Features: {len(feature_columns)}")
    print(f"  - Models trained: 3 (Linear Regression, Decision Tree, Random Forest)")
    print(f"  - Best model: {metrics_df.loc[metrics_df['R2'].idxmax(), 'Model']}")
    print(f"  - Best R² score: {metrics_df['R2'].max():.4f}")
    print(f"  - Output directory: {output_dir}")
    print("\n✓ All files saved successfully!")
    print("=" * 80)


if __name__ == "__main__":
    main()
