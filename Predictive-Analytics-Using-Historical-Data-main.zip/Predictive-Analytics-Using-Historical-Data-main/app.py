"""
Streamlit Dashboard Application
Interactive web interface for sales forecasting
"""

import streamlit as st
import pandas as pd
import numpy as np
import os
import sys
from datetime import datetime
from pathlib import Path

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "src"))

from src import (
    DataGenerator,
    DataPreprocessor,
    FeatureEngineer,
    ModelTrainer,
    ModelEvaluator,
    SalesForecaster,
    Visualizer,
    RAW_DATA_PATH,
    PROCESSED_DATA_PATH,
)


# Page configuration
st.set_page_config(
    page_title="Sales Forecasting Dashboard",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Custom CSS
st.markdown(
    """
    <style>
    .main {
        padding-top: 0.5rem;
    }
    .metric-card {
        background-color: #f0f2f6;
        padding: 1rem;
        border-radius: 0.5rem;
        margin: 0.5rem 0;
    }
    </style>
    """,
    unsafe_allow_html=True,
)


@st.cache_resource
def load_models():
    """Load trained models."""
    forecaster = SalesForecaster()
    forecaster.load_models()
    return forecaster


@st.cache_data
def load_sample_data():
    """Load or generate sample data."""
    if Path(PROCESSED_DATA_PATH).exists():
        preprocessor = DataPreprocessor()
        return preprocessor.load_preprocessed_data(PROCESSED_DATA_PATH)
    else:
        generator = DataGenerator()
        df = generator.generate_sales_data()
        df = generator.add_features(df)
        return df


def main():
    """Main application."""
    # Sidebar
    st.sidebar.title("📊 Sales Forecasting")
    page = st.sidebar.radio(
        "Navigation",
        [
            "Dashboard",
            "Data Analysis",
            "Model Training",
            "Forecasting",
            "Model Comparison",
            "Upload Data",
        ],
    )

    if page == "Dashboard":
        show_dashboard()
    elif page == "Data Analysis":
        show_data_analysis()
    elif page == "Model Training":
        show_model_training()
    elif page == "Forecasting":
        show_forecasting()
    elif page == "Model Comparison":
        show_model_comparison()
    elif page == "Upload Data":
        show_upload_data()


def show_dashboard():
    """Display main dashboard."""
    st.title("📊 Sales Forecasting Dashboard")

    col1, col2, col3 = st.columns(3)

    with col1:
        st.metric("📈 Total Records", "1,095", "+3 years of data")

    with col2:
        st.metric("🤖 Models Trained", "3", "LR, DT, RF")

    with col3:
        st.metric("🎯 Forecast Period", "30 days", "Next month")

    st.divider()

    # Load sample data
    df = load_sample_data()

    # Display statistics
    st.subheader("📊 Sales Statistics")
    col1, col2, col3, col4 = st.columns(4)

    with col1:
        st.metric("Average Sales", f"${df['sales'].mean():.2f}")

    with col2:
        st.metric("Median Sales", f"${df['sales'].median():.2f}")

    with col3:
        st.metric("Max Sales", f"${df['sales'].max():.2f}")

    with col4:
        st.metric("Min Sales", f"${df['sales'].min():.2f}")

    st.divider()

    # Visualizations
    st.subheader("📈 Sales Trend")
    visualizer = Visualizer()
    fig = visualizer.plot_sales_trend(df)
    st.pyplot(fig)

    col1, col2 = st.columns(2)

    with col1:
        st.subheader("📊 Sales Distribution")
        fig = visualizer.plot_sales_distribution(df)
        st.pyplot(fig)

    with col2:
        st.subheader("📅 Monthly Average")
        fig = visualizer.plot_monthly_average(df)
        st.pyplot(fig)

    # Display raw data
    st.subheader("📋 Raw Data (Last 20 rows)")
    st.dataframe(df.tail(20), use_container_width=True)


def show_data_analysis():
    """Display data analysis page."""
    st.title("📊 Data Analysis")

    df = load_sample_data()

    # Data summary
    st.subheader("Dataset Summary")
    col1, col2, col3 = st.columns(3)

    with col1:
        st.metric("Total Records", len(df))

    with col2:
        st.metric("Date Range", f"{df['date'].min().date()} to {df['date'].max().date()}")

    with col3:
        st.metric("Missing Values", df.isnull().sum().sum())

    st.divider()

    # Statistical summary
    st.subheader("Statistical Summary")
    st.dataframe(df["sales"].describe(), use_container_width=True)

    st.divider()

    # Visualizations
    visualizer = Visualizer()

    col1, col2 = st.columns(2)

    with col1:
        st.subheader("Sales Trend")
        fig = visualizer.plot_sales_trend(df)
        st.pyplot(fig)

    with col2:
        st.subheader("Sales Distribution")
        fig = visualizer.plot_sales_distribution(df)
        st.pyplot(fig)

    st.subheader("Monthly Average Sales")
    fig = visualizer.plot_monthly_average(df)
    st.pyplot(fig)


def show_model_training():
    """Display model training page."""
    st.title("🤖 Model Training")

    st.info(
        "This page allows you to train new models using the current dataset. "
        "Training may take a few moments."
    )

    if st.button("🚀 Start Training", key="train_button"):
        st.info("Training in progress... Please wait.")

        # Load data
        df = load_sample_data()
        
        # Preprocessing
        st.write("Preprocessing data...")
        preprocessor = DataPreprocessor()
        df_processed = preprocessor.preprocess(df, handle_outliers=True, normalize=True, fit=True)

        # Feature engineering
        st.write("Engineering features...")
        feature_engineer = FeatureEngineer()
        df_engineered = feature_engineer.engineer_features(df_processed)
        feature_columns = feature_engineer.get_feature_names(df_engineered)

        # Model training
        st.write("Training models...")
        trainer = ModelTrainer()
        X_train, X_test, y_train, y_test = trainer.prepare_data(df_engineered, feature_columns)

        trainer.train_linear_regression()
        trainer.train_decision_tree()
        trainer.train_random_forest()

        # Evaluation
        st.write("Evaluating models...")
        evaluator = ModelEvaluator()

        results = []
        for model_name, model in trainer.models.items():
            y_pred = trainer.predict(model, X_test)
            metrics = evaluator.evaluate_model(
                y_test.values,
                y_pred,
                model_name=model_name,
                n_features=X_test.shape[1],
            )
            results.append(metrics)

        metrics_df = pd.DataFrame(results)

        # Save models
        trainer.save_all_models()

        st.success("✓ Training completed successfully!")

        # Display results
        st.subheader("📊 Model Performance")
        st.dataframe(metrics_df, use_container_width=True)

        # Plot comparison
        visualizer = Visualizer()
        fig = visualizer.plot_model_comparison(metrics_df)
        st.pyplot(fig)


def show_forecasting():
    """Display forecasting page."""
    st.title("🔮 Sales Forecasting")

    # Model selection
    model_option = st.selectbox(
        "Select Model",
        ["Linear Regression", "Decision Tree", "Random Forest", "Ensemble"],
    )

    # Forecast period
    forecast_days = st.slider("Forecast Period (days)", min_value=7, max_value=90, value=30)

    if st.button("📊 Generate Forecast", key="forecast_button"):
        st.info("Generating forecast... Please wait.")

        # Load data and models
        df = load_sample_data()
        forecaster = load_models()

        # Feature engineering
        feature_engineer = FeatureEngineer()
        df_engineered = feature_engineer.engineer_features(df)

        # Generate forecast
        if model_option == "Ensemble":
            forecast_df = forecaster.ensemble_forecast(df_engineered, periods=forecast_days, feature_engineer=feature_engineer)
        else:
            forecast_df = forecaster.forecast(
                df_engineered, periods=forecast_days, model_name=model_option, feature_engineer=feature_engineer
            )

        st.success("✓ Forecast generated!")

        # Display forecast
        st.subheader(f"📈 {model_option} Forecast")
        st.dataframe(forecast_df, use_container_width=True)

        # Visualization
        visualizer = Visualizer()
        fig = visualizer.plot_forecast_comparison(df, forecast_df, title=f"{model_option} Forecast")
        st.pyplot(fig)

        # Statistics
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Average Forecast", f"${forecast_df['forecasted_sales'].mean():.2f}")
        with col2:
            st.metric("Min Forecast", f"${forecast_df['forecasted_sales'].min():.2f}")
        with col3:
            st.metric("Max Forecast", f"${forecast_df['forecasted_sales'].max():.2f}")

        # Download
        csv = forecast_df.to_csv(index=False)
        st.download_button(
            label="📥 Download Forecast CSV",
            data=csv,
            file_name=f"forecast_{model_option.replace(' ', '_').lower()}.csv",
            mime="text/csv",
        )


def show_model_comparison():
    """Display model comparison page."""
    st.title("🏆 Model Comparison")

    df = load_sample_data()

    st.info("Loading all models and generating predictions...")

    # Preprocessing and feature engineering
    preprocessor = DataPreprocessor()
    df_processed = preprocessor.preprocess(df, handle_outliers=True, normalize=True, fit=False)

    feature_engineer = FeatureEngineer()
    df_engineered = feature_engineer.engineer_features(df_processed)
    feature_columns = feature_engineer.get_feature_names(df_engineered)

    # Train models for comparison
    trainer = ModelTrainer()
    X_train, X_test, y_train, y_test = trainer.prepare_data(df_engineered, feature_columns)

    trainer.train_linear_regression()
    trainer.train_decision_tree()
    trainer.train_random_forest()

    # Evaluation
    evaluator = ModelEvaluator()
    results = []

    for model_name, model in trainer.models.items():
        y_pred = trainer.predict(model, X_test)
        metrics = evaluator.evaluate_model(
            y_test.values,
            y_pred,
            model_name=model_name,
            n_features=X_test.shape[1],
        )
        results.append(metrics)

    metrics_df = pd.DataFrame(results)

    st.subheader("📊 Model Metrics Comparison")
    st.dataframe(metrics_df, use_container_width=True)

    # Visualizations
    col1, col2 = st.columns(2)

    with col1:
        visualizer = Visualizer()
        fig = visualizer.plot_model_comparison(metrics_df)
        st.pyplot(fig)

    with col2:
        # Best model summary
        st.subheader("🏆 Best Model")
        best_model_idx = metrics_df["R2"].idxmax()
        best_model = metrics_df.iloc[best_model_idx]

        col_a, col_b = st.columns(2)
        with col_a:
            st.metric("Model", best_model["Model"])
            st.metric("R²", f"{best_model['R2']:.4f}")

        with col_b:
            st.metric("RMSE", f"{best_model['RMSE']:.4f}")
            st.metric("MAE", f"{best_model['MAE']:.4f}")

    st.divider()

    # Detailed comparison table
    st.subheader("📋 Detailed Metrics")

    comparison_data = []
    for model_name, model in trainer.models.items():
        y_pred = trainer.predict(model, X_test)
        comparison_data.append({
            "Model": model_name,
            "MAE": evaluator.calculate_mae(y_test.values, y_pred),
            "MSE": evaluator.calculate_mse(y_test.values, y_pred),
            "RMSE": evaluator.calculate_rmse(y_test.values, y_pred),
            "MAPE": evaluator.calculate_mape(y_test.values, y_pred),
            "R²": evaluator.calculate_r2(y_test.values, y_pred),
        })

    comparison_df = pd.DataFrame(comparison_data)
    st.dataframe(comparison_df, use_container_width=True)


def show_upload_data():
    """Display upload data page."""
    st.title("📤 Upload Custom Data")

    st.info(
        "Upload your own sales data in CSV format. "
        "The file must contain 'date' and 'sales' columns."
    )

    uploaded_file = st.file_uploader("Choose a CSV file", type="csv")

    if uploaded_file is not None:
        # Read uploaded file
        df = pd.read_csv(uploaded_file)

        st.success("✓ File uploaded successfully!")

        # Validate columns
        if "date" not in df.columns or "sales" not in df.columns:
            st.error("❌ File must contain 'date' and 'sales' columns")
            return

        st.dataframe(df.head(), use_container_width=True)

        # Validate data
        preprocessor = DataPreprocessor()
        is_valid, message = preprocessor.validate_data(df)

        if is_valid:
            st.success(f"✓ {message}")

            # Show statistics
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("Records", len(df))
            with col2:
                st.metric("Average Sales", f"${df['sales'].mean():.2f}")
            with col3:
                st.metric("Missing Values", df.isnull().sum().sum())

            # Visualizations
            visualizer = Visualizer()
            fig = visualizer.plot_sales_trend(df)
            st.pyplot(fig)

        else:
            st.error(f"❌ Validation failed: {message}")


if __name__ == "__main__":
    main()
